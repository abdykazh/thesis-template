# Write in Markdown

This is just an exemplary file to show the inclusion of **markdown**.
And citations @Bithappens16Template are working as well.
However, this feature is not supported by classical LaTeX-Editors.
In order to use it, you need to use the makefile based build or enable the continues integration pipeline in your repo.
For this read more about [GitHuB Actions](https://docs.github.com/en/actions) or [GitLabCI](https://docs.gitlab.com/ee/ci/) in their official documentations.
